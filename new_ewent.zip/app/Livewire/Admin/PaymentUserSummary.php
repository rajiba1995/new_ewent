<?php

namespace App\Livewire\Admin;

use Livewire\Component;

class PaymentUserSummary extends Component
{
    public function render()
    {
        return view('livewire.admin.payment-user-summary');
    }
}

<div class="row mb-4">
    <style>
        .side-modal {
            position: fixed;
            top: 0;
            right: -400px; /* Initially hidden */
            width: 500px;
            height: 690px;
            background: #fff;
            box-shadow: -2px 0 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            transition: right 0.3s ease-in-out;
            z-index: 10000;
        }

        .side-modal.open {
            right: 0;
        }

        .side-modal-content {
            display: flex;
            flex-direction: column;
            max-height: -webkit-fill-available;
            overflow-y: auto;
        }

        .close-btn {
            position: absolute;
            top: 10px;
            right: 10px;
            font-size: 20px;
            border: none;
            background: none;
            cursor: pointer;
        }

        .overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 1000;
        }
        
        /* 17-03-2025 */
        .side-modal {
            height: 100vh;
        }
        .side-modal-content {
            height: calc(100vh - 110px);
        }
        .table{
            font-size: 12px;
        }
    </style>
    <div class="col-lg-12 justify-content-left">
       <h5 class="mb-0">Rider Management</h5>
       <div>
            <small class="text-dark fw-medium">Riders</small>
            <small class="text-light fw-medium arrow">Engagement</small>
       </div>
    </div>
    <div class="col-lg-12 justify-content-left">
        <div class="row">
            <!--[if BLOCK]><![endif]--><?php if(session()->has('message')): ?>
                <div class="alert alert-success" id="flashMessage">
                    <?php echo e(session('message')); ?>

                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            <?php if(session()->has('error')): ?>
                <div class="alert alert-danger" id="flashMessage">
                    <?php echo e(session('error')); ?>

                </div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </div>
    </div>
    
    <div class="col-lg-12 col-md-6 mb-md-0 my-4">
        <div class="row">
            <div class="col-12">
                <div class="card mb-2 py-4 px-2">
                    <div class="row justify-content-end">
                        <div class="col-lg-6 col-6 my-auto mb-2">
                            <div class="d-flex align-items-center justify-content-end">
                                <input type="text" wire:model="search" 
                                       class="form-control border border-2 p-2 custom-input-sm" 
                                       placeholder="Search by Rider's Name, Email, or Mobile Number">
                                <button type="button" wire:click="btn_search" 
                                        class="btn btn-primary text-white mb-0 custom-input-sm ms-2">
                                    <span class="material-icons">Search</span>
                                </button>
                                <!-- Refresh Button -->
                                <button type="button" wire:click="reset_search" 
                                        class="btn btn-outline-danger waves-effect mb-0 custom-input-sm ms-2">
                                    <span class="material-icons">Refresh</span>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="card mb-6">
                    <div class="card-header px-0 pt-0">
                      <div class="nav-align-top">
                        <ul class="nav nav-tabs nav-fill" role="tablist">
                          <li class="nav-item" role="presentation" wire:click="tab_change(1)">
                            <button type="button" class="nav-link waves-effect <?php echo e($active_tab==1?"active":""); ?>" role="tab" data-bs-toggle="tab"
                              data-bs-target="#navs-justified-1" aria-controls="navs-justified-1" aria-selected="false"
                              tabindex="-1">
                              <span class="d-none d-sm-block engagement_header">
                                <i class="tf-icons ri-user-3-line me-1_5"></i>
                                </i> All <span
                                  class="badge rounded-pill badge-center h-px-20 w-px-20 bg-label-secondary ms-1_5 pt-50"><?php echo e(count($all_users)); ?></span>
                                </span>
                                <i class="ri-user-3-line ri-20px d-sm-none"></i>
                          </li>
                          <li class="nav-item" role="presentation" wire:click="tab_change(2)">
                            <button type="button" class="nav-link waves-effect <?php echo e($active_tab==2?"active":""); ?>" role="tab" data-bs-toggle="tab"
                              data-bs-target="#navs-justified-2" aria-controls="navs-justified-2" aria-selected="false"
                              tabindex="-1">
                              <span class="d-none d-sm-block engagement_header">
                                <i class="tf-icons ri-user-3-line me-1_5"></i>
                                </i> Await <span
                                  class="badge rounded-pill badge-center h-px-20 w-px-20 bg-label-dark ms-1_5 pt-50"><?php echo e(count($await_users)); ?></span>
                                </span>
                                <i class="ri-user-3-line ri-20px d-sm-none"></i>
                            </button>
                          </li>
                          <li class="nav-item" role="presentation" wire:click="tab_change(3)">
                            <button type="button" class="nav-link waves-effect <?php echo e($active_tab==3?"active":""); ?>" role="tab" data-bs-toggle="tab"
                              data-bs-target="#navs-justified-3" aria-controls="navs-justified-3" aria-selected="true">
                              <span class="d-none d-sm-block engagement_header">
                                <i class="tf-icons ri-user-3-line me-1_5"></i>
                                </i> Ready To Assign <span
                                  class="badge rounded-pill badge-center h-px-20 w-px-20 bg-label-success ms-1_5 pt-50"><?php echo e(count($ready_to_assigns)); ?></span>
                                </span>
                                <i class="ri-user-3-line ri-20px d-sm-none"></i>
                            </button>
                          </li>
                          <li class="nav-item" role="presentation" wire:click="tab_change(4)">
                            <button type="button" class="nav-link waves-effect <?php echo e($active_tab==4?"active":""); ?>" role="tab" data-bs-toggle="tab"
                              data-bs-target="#navs-justified-4" aria-controls="navs-justified-4" aria-selected="true">
                              <span class="d-none d-sm-block engagement_header">
                                <i class="tf-icons ri-user-3-line me-1_5"></i>
                                </i> Active <span
                                  class="badge rounded-pill badge-center h-px-20 w-px-20 bg-label-success ms-1_5 pt-50"><?php echo e(count($active_users)); ?></span>
                                </span>
                                <i class="ri-user-3-line ri-20px d-sm-none"></i>
                            </button>
                          </li>
                          <li class="nav-item" role="presentation" wire:click="tab_change(5)">
                            <button type="button" class="nav-link waves-effect <?php echo e($active_tab==5?"active":""); ?>" role="tab" data-bs-toggle="tab"
                              data-bs-target="#navs-justified-5" aria-controls="navs-justified-5" aria-selected="true">
                              <span class="d-none d-sm-block engagement_header">
                                <i class="tf-icons ri-user-3-line me-1_5"></i>
                                </i> Inactive <span
                                  class="badge rounded-pill badge-center h-px-20 w-px-20 bg-label-danger ms-1_5 pt-50"><?php echo e(count($ready_to_assigns)); ?></span>
                                </span>
                                <i class="ri-user-3-line ri-20px d-sm-none"></i>
                            </button>
                          </li>
                          <li class="nav-item" role="presentation" wire:click="tab_change(6)">
                            <button type="button" class="nav-link waves-effect <?php echo e($active_tab==6?"active":""); ?>" role="tab" data-bs-toggle="tab"
                              data-bs-target="#navs-justified-6" aria-controls="navs-justified-6" aria-selected="true">
                              <span class="d-none d-sm-block engagement_header">
                                <i class="tf-icons ri-user-3-line me-1_5"></i>
                                </i> Suspended <span
                                  class="badge rounded-pill badge-center h-px-20 w-px-20 bg-label-danger ms-1_5 pt-50"><?php echo e(count($ready_to_assigns)); ?></span>
                                </span>
                                <i class="ri-user-3-line ri-20px d-sm-none"></i>
                            </button>
                          </li>
                          <li class="nav-item" role="presentation" wire:click="tab_change(7)">
                            <button type="button" class="nav-link waves-effect <?php echo e($active_tab==7?"active":""); ?>" role="tab" data-bs-toggle="tab"
                              data-bs-target="#navs-justified-7" aria-controls="navs-justified-7" aria-selected="true">
                              <span class="d-none d-sm-block engagement_header">
                                <i class="tf-icons ri-user-3-line me-1_5"></i>
                                </i> Cancel Subscription Request <span
                                  class="badge rounded-pill badge-center h-px-20 w-px-20 bg-label-danger ms-1_5 pt-50"><?php echo e(count($ready_to_assigns)); ?></span>
                                </span>
                                <i class="ri-user-3-line ri-20px d-sm-none"></i>
                            </button>
                          </li>
                        </ul>
                      </div>
                    </div>
                    <div class="card-body">
                      <div class="tab-content p-0">
                        <div class="tab-pane fade <?php echo e($active_tab==1?"active show":""); ?>" id="navs-justified-home" role="tabpanel">
                            
                            <div class="table-responsive p-0">
                                <table class="table align-items-center mb-0">
                                    <thead>
                                        <tr>
                                            <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 align-middle">SL</th>
                                            <th class="text-start text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 align-middle">Riders</th>
                                            <th class="text-start text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 align-middle">Payment Status</th>
                                            <th class="text-start text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 align-middle">Vehicle Model</th>
                                            <th class="text-start text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 align-middle">Subscription</th>
                                            <th class="text-end text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 align-middle px-4">DashBoard</th>
                                            <th class="text-end text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 align-middle px-4">Documents</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                       
                                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $all_users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $al_user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $colors = ['bg-label-primary', 'bg-label-success', 'bg-label-info', 'bg-label-secondary', 'bg-label-danger', 'bg-label-warning'];
                                            $colorClass = $colors[$k % count($colors)]; // Rotate colors based on index
                                        ?>
                                            <tr>
                                                <td class="align-middle text-center"><?php echo e($k + 1); ?></td>
                                                <td class="sorting_1">
                                                    <div class="d-flex justify-content-start align-items-center customer-name">
                                                        <div class="avatar-wrapper me-3">
                                                            <div class="avatar avatar-sm">
                                                                <!--[if BLOCK]><![endif]--><?php if($al_user->profile_image): ?>
                                                                    <img src="<?php echo e(asset($al_user->profile_image)); ?>" alt="Avatar" class="rounded-circle">
                                                                <?php else: ?>
                                                                    <div class="avatar-initial rounded-circle <?php echo e($colorClass); ?>">
                                                                        <?php echo e(strtoupper(substr($al_user->name, 0, 1))); ?><?php echo e(strtoupper(substr(strrchr($al_user->name, ' '), 1, 1))); ?>

                                                                    </div>
                                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                            </div>
                                                        </div>
                                                        <div class="d-flex flex-column">
                                                            <a href="<?php echo e(route('admin.customer.details', $al_user->id)); ?>"
                                                                class="text-heading"><span class="fw-medium text-truncate"><?php echo e(ucwords($al_user->name)); ?></span>
                                                            </a>
                                                            <small class="text-truncate"><?php echo e($al_user->email); ?> | <?php echo e($al_user->country_code); ?> <?php echo e($al_user->mobile); ?></small>
                                                        <div>
                                                    </div>
                                                </td>
                                                <td class="align-middle text-start">
                                                    <!--[if BLOCK]><![endif]--><?php if($al_user->latest_order): ?>
                                                        <!--[if BLOCK]><![endif]--><?php if($al_user->latest_order->payment_status=="completed"): ?>
                                                            <span class="badge bg-label-success mb-0 cursor-pointer text-uppercase"><?php echo e($al_user->latest_order->payment_status); ?></span>
                                                        <?php else: ?>
                                                            <span class="badge bg-label-warning mb-0 cursor-pointer text-uppercase"><?php echo e($al_user->latest_order->payment_status); ?></span>
                                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                    <?php else: ?>
                                                        <span class="badge bg-label-danger mb-0 cursor-pointer">NOT PAID</span>
                                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                </td>
                                                <td class="align-middle text-start"><?php echo e($al_user->latest_order?$al_user->latest_order->product->title:"N/A"); ?></td>
                                                <td class="align-middle text-start">
                                                    <!--[if BLOCK]><![endif]--><?php if(optional($al_user->latest_order)->subscription): ?>
                                                        <?php echo e(ucwords($al_user->latest_order->subscription->subscription_type)); ?>

                                                    <?php else: ?>
                                                        N/A
                                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                </td>
                                                <td class="align-middle text-sm text-center">
                                                    <div class="dropdown cursor-pointer">
                                                        <span class="badge px-2 rounded-pill bg-label-secondary dropdown-toggle" id="exploreDropdown_all_<?php echo e($al_user->id); ?>" data-bs-toggle="dropdown" aria-expanded="false">Explore</span>
                                                        <ul class="dropdown-menu" aria-labelledby="exploreDropdown_all_<?php echo e($al_user->id); ?>">
                                                            
                                                            <li><a class="dropdown-item" href="#">History</a></li>
                                                        </ul>
                                                    </div>
                                                </td>
                                                <td class="align-middle text-end px-4">
                                                    <button class="btn btn-outline-success waves-effect mb-0 custom-input-sm ms-2"
                                                            wire:click="showCustomerDetails(<?php echo e($al_user->id); ?>)">
                                                        View
                                                    </button>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                    </tbody>
                                </table>
                                <div class="d-flex justify-content-end mt-3 paginator">
                                    <?php echo e($all_users->links()); ?> <!-- Pagination links -->
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade <?php echo e($active_tab==2?"active show":""); ?>" id="navs-justified-profile" role="tabpanel">
                            <div class="table-responsive p-0">
                                <table class="table align-items-center mb-0">
                                    <thead>
                                        <tr>
                                            <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 align-middle">SL</th>
                                            <th class="text-start text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 align-middle">Riders</th>
                                            <th class="text-start text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 align-middle">Payment Status</th>
                                            <th class="text-start text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 align-middle">Vehicle Model</th>
                                            <th class="text-start text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 align-middle">Dashboard</th>
                                            <th class="text-end text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 align-middle px-4">Documents</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                       
                                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $await_users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $aw_user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $colors = ['bg-label-primary', 'bg-label-success', 'bg-label-info', 'bg-label-secondary', 'bg-label-danger', 'bg-label-warning'];
                                            $colorClass = $colors[$k % count($colors)]; // Rotate colors based on index
                                        ?>
                                            <tr>
                                                <td class="align-middle text-center"><?php echo e($k + 1); ?></td>
                                                <td class="sorting_1">
                                                    <div class="d-flex justify-content-start align-items-center customer-name">
                                                        <div class="avatar-wrapper me-3">
                                                            <div class="avatar avatar-sm">
                                                                <!--[if BLOCK]><![endif]--><?php if($aw_user->image): ?>
                                                                    <img src="<?php echo e(asset($aw_user->image)); ?>" alt="Avatar" class="rounded-circle">
                                                                <?php else: ?>
                                                                    <div class="avatar-initial rounded-circle <?php echo e($colorClass); ?>">
                                                                        <?php echo e(strtoupper(substr($aw_user->name, 0, 1))); ?><?php echo e(strtoupper(substr(strrchr($aw_user->name, ' '), 1, 1))); ?>

                                                                    </div>
                                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                            </div>
                                                        </div>
                                                        <div class="d-flex flex-column">
                                                            <a href="<?php echo e(route('admin.customer.details', $aw_user->id)); ?>"
                                                                class="text-heading"><span class="fw-medium text-truncate"><?php echo e(ucwords($aw_user->name)); ?></span>
                                                            </a>
                                                            <small class="text-truncate"><?php echo e($aw_user->email); ?> </small>
                                                            
                                                        <div>
                                                    </div>
                                                    <td class="align-middle text-start">
                                                        <!--[if BLOCK]><![endif]--><?php if($aw_user->await_order): ?>
                                                            <!--[if BLOCK]><![endif]--><?php if($aw_user->await_order->payment_status=="completed"): ?>
                                                                <span class="badge bg-label-success mb-0 cursor-pointer text-uppercase"><?php echo e($aw_user->await_order->payment_status); ?></span>
                                                            <?php else: ?>
                                                                <span class="badge bg-label-warning mb-0 cursor-pointer text-uppercase"><?php echo e($aw_user->await_order->payment_status); ?></span>
                                                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                        <?php else: ?>
                                                            <span class="badge bg-label-danger mb-0 cursor-pointer">NOT PAID</span>
                                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                    </td>
                                                    <td class="align-middle text-start"><?php echo e($aw_user->await_order?$aw_user->await_order->product->title:"N/A"); ?></td>
                                                    <td class="align-middle text-sm text-center">
                                                        <div class="dropdown cursor-pointer">
                                                            <span class="badge px-2 rounded-pill bg-label-secondary dropdown-toggle" id="exploreDropdown_await_<?php echo e($aw_user->id); ?>" data-bs-toggle="dropdown" aria-expanded="false">Explore</span>
                                                            <ul class="dropdown-menu" aria-labelledby="exploreDropdown_await_<?php echo e($aw_user->id); ?>">
                                                                
                                                                <li><a class="dropdown-item" href="#">History</a></li>
                                                            </ul>
                                                        </div>
                                                    </td>
                                                    <td class="align-middle text-end px-4">
                                                        <button class="btn btn-outline-success waves-effect mb-0 custom-input-sm ms-2"
                                                            wire:click="showCustomerDetails(<?php echo e($aw_user->id); ?>)">
                                                        View
                                                    </button>
                                                    </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                    </tbody>
                                </table>
                                <div class="d-flex justify-content-end mt-3 paginator">
                                    <?php echo e($await_users->links()); ?> <!-- Pagination links -->
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade <?php echo e($active_tab==3?"active show":""); ?>" id="navs-justified-messages" role="tabpanel">
                            <div class="table-responsive p-0">
                                <table class="table align-items-center mb-0">
                                    <thead>
                                        <tr>
                                            <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 align-middle">SL</th>
                                            <th class="text-start text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 align-middle">Riders</th>
                                            <th class="text-start text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 align-middle">Payment Status</th>
                                            <th class="text-start text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 align-middle">Vehicle Model</th>
                                            <th class="text-start text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 align-middle">Subscription</th>
                                            <th class="text-end text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 align-middle px-4">Documents</th>
                                            <th class="text-end text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 align-middle px-4">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                       
                                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $ready_to_assigns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $rta_user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $colors = ['bg-label-primary', 'bg-label-success', 'bg-label-info', 'bg-label-secondary', 'bg-label-danger', 'bg-label-warning'];
                                            $colorClass = $colors[$k % count($colors)]; // Rotate colors based on index
                                        ?>
                                            <tr>
                                                <td class="align-middle text-center"><?php echo e($k + 1); ?></td>
                                                <td class="sorting_1">
                                                    <div class="d-flex justify-content-start align-items-center customer-name">
                                                        <div class="avatar-wrapper me-3">
                                                            <div class="avatar avatar-sm">
                                                                <!--[if BLOCK]><![endif]--><?php if($rta_user->image): ?>
                                                                    <img src="<?php echo e(asset($rta_user->image)); ?>" alt="Avatar" class="rounded-circle">
                                                                <?php else: ?>
                                                                    <div class="avatar-initial rounded-circle <?php echo e($colorClass); ?>">
                                                                        <?php echo e(strtoupper(substr($rta_user->name, 0, 1))); ?><?php echo e(strtoupper(substr(strrchr($rta_user->name, ' '), 1, 1))); ?>

                                                                    </div>
                                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                            </div>
                                                        </div>
                                                        <div class="d-flex flex-column">
                                                            <a href="<?php echo e(route('admin.customer.details', $rta_user->id)); ?>"
                                                                class="text-heading"><span class="fw-medium text-truncate"><?php echo e(ucwords($rta_user->name)); ?></span>
                                                            </a>
                                                            <small class="text-truncate"><?php echo e($rta_user->email); ?> | <?php echo e($rta_user->country_code); ?> <?php echo e($rta_user->mobile); ?></small>
                                                        <div>
                                                    </div>
                                                </td>
                                                <td class="align-middle text-start">
                                                    <!--[if BLOCK]><![endif]--><?php if($rta_user->ready_to_assign_order): ?>
                                                        <!--[if BLOCK]><![endif]--><?php if($rta_user->ready_to_assign_order->payment_status=="completed"): ?>
                                                            <span class="badge bg-label-success mb-0 cursor-pointer text-uppercase"><?php echo e($rta_user->ready_to_assign_order->payment_status); ?></span>
                                                        <?php else: ?>
                                                            <span class="badge bg-label-warning mb-0 cursor-pointer text-uppercase"><?php echo e($rta_user->ready_to_assign_order->payment_status); ?></span>
                                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                    <?php else: ?>
                                                        <span class="badge bg-label-danger mb-0 cursor-pointer">NOT PAID</span>
                                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                </td>
                                                <td class="align-middle text-start"><?php echo e($rta_user->ready_to_assign_order?$rta_user->ready_to_assign_order->product->title:"N/A"); ?></td>
                                                <td class="align-middle text-start">
                                                    <!--[if BLOCK]><![endif]--><?php if(optional($rta_user->ready_to_assign_order)->subscription): ?>
                                                        <?php echo e(ucwords($rta_user->ready_to_assign_order->subscription->subscription_type)); ?>

                                                    <?php else: ?>
                                                        N/A
                                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                </td>
                                                <td class="align-middle text-end px-4">
                                                    <button class="btn btn-outline-success waves-effect mb-0 custom-input-sm ms-2"
                                                            wire:click="showCustomerDetails(<?php echo e($rta_user->id); ?>)">
                                                        View
                                                    </button>
                                                </td>
                                                <td class="align-middle text-end px-4">
                                                    <button class="btn btn-success text-white mb-0 custom-input-sm ms-2" wire:click="OpenAssignedForm(<?php echo e($rta_user->id); ?>,<?php echo e(optional($rta_user->ready_to_assign_order)->product->id ?? 'N/A'); ?>,<?php echo e($rta_user->ready_to_assign_order->id); ?>)">
                                                        Assign
                                                    </button>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                    </tbody>
                                </table>
                                <div class="d-flex justify-content-end mt-3 paginator">
                                    <?php echo e($ready_to_assigns->links()); ?> <!-- Pagination links -->
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade <?php echo e($active_tab==4?"active show":""); ?>" id="navs-justified-messages" role="tabpanel">
                            <div class="table-responsive p-0">
                                <table class="table align-items-center mb-0">
                                    <thead>
                                        <tr>
                                            <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 align-middle">SL</th>
                                            <th class="text-start text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 align-middle">Riders</th>
                                            <th class="text-start text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 align-middle">Vehicle Info</th>
                                            <th class="text-start text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 align-middle">Status</th>
                                            <th class="text-start text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 align-middle">Allocated <br> Date/Time</th>
                                            <th class="text-end text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 align-middle px-4">Expected End <br> Date/Time</th>
                                            <th class="text-end text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 align-middle px-4">Dashboard</th>
                                            <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 align-middle px-4">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                       
                                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $active_users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $ac_user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $colors = ['bg-label-primary', 'bg-label-success', 'bg-label-info', 'bg-label-secondary', 'bg-label-danger', 'bg-label-warning'];
                                            $colorClass = $colors[$k % count($colors)]; // Rotate colors based on index
                                        ?>
                                            <tr>
                                                <td class="align-middle text-center"><?php echo e($k + 1); ?></td>
                                                <td class="sorting_1">
                                                    <div class="d-flex justify-content-start align-items-center customer-name">
                                                        <div class="avatar-wrapper me-3">
                                                            <div class="avatar avatar-sm">
                                                                <!--[if BLOCK]><![endif]--><?php if($ac_user->image): ?>
                                                                    <img src="<?php echo e(asset($ac_user->image)); ?>" alt="Avatar" class="rounded-circle">
                                                                <?php else: ?>
                                                                    <div class="avatar-initial rounded-circle <?php echo e($colorClass); ?>">
                                                                        <?php echo e(strtoupper(substr($ac_user->name, 0, 1))); ?><?php echo e(strtoupper(substr(strrchr($ac_user->name, ' '), 1, 1))); ?>

                                                                    </div>
                                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                            </div>
                                                        </div>
                                                        <div class="d-flex flex-column">
                                                            <a href="<?php echo e(route('admin.customer.details', $ac_user->id)); ?>"
                                                                class="text-heading"><span class="fw-medium text-truncate"><?php echo e(ucwords($ac_user->name)); ?></span>
                                                            </a>
                                                            <small class="text-truncate"><?php echo e($ac_user->email); ?> | <?php echo e($ac_user->country_code); ?> <?php echo e($ac_user->mobile); ?></small>
                                                        <div>
                                                    </div>
                                                </td>
                                                <td class="align-middle text-start">
                                                    <!--[if BLOCK]><![endif]--><?php if(optional($ac_user->active_vehicle)->stock && optional($ac_user->active_order)->product): ?>
                                                        <?php echo e(ucwords(optional($ac_user->active_vehicle->stock)->vehicle_number)); ?> <br>
                                                        <?php echo e(ucwords(optional($ac_user->active_order->product)->title)); ?>

                                                    <?php else: ?>
                                                        N/A
                                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                </td>
                                                <td class="align-middle text-start">
                                                    <!--[if BLOCK]><![endif]--><?php if($ac_user->active_order): ?>
                                                        <!--[if BLOCK]><![endif]--><?php if($ac_user->active_order->payment_status=="completed"): ?>
                                                            <span class="badge bg-label-success mb-0 cursor-pointer text-uppercase">PAID</span>
                                                        <?php else: ?>
                                                            <span class="badge bg-label-warning mb-0 cursor-pointer text-uppercase"><?php echo e($ac_user->active_order->payment_status); ?></span>
                                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                    <?php else: ?>
                                                        <span class="badge bg-label-danger mb-0 cursor-pointer">NOT PAID</span>
                                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                </td>
                                                <td class="align-middle text-start">
                                                    <!--[if BLOCK]><![endif]--><?php if($ac_user->active_order->rent_start_date): ?>
                                                        <small class="text-muted"><?php echo e(date('d M y h:i A', strtotime($ac_user->active_order->rent_start_date))); ?></small>
                                                    <?php else: ?>
                                                        ........
                                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                    
                                                </td>
                                                <td class="align-middle text-start">
                                                    <!--[if BLOCK]><![endif]--><?php if($ac_user->active_order->rent_end_date): ?>
                                                        <small class="text-muted"><?php echo e(date('d M y h:i A', strtotime($ac_user->active_order->rent_end_date))); ?></small>
                                                    <?php else: ?>
                                                        ........
                                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                </td>
                                                <td class="align-middle text-sm text-center">
                                                    <div class="dropdown cursor-pointer">
                                                        <span class="badge px-2 rounded-pill bg-label-secondary dropdown-toggle" id="exploreDropdown_active_<?php echo e($ac_user->id); ?>" data-bs-toggle="dropdown" aria-expanded="false">Explore</span>
                                                        <ul class="dropdown-menu" aria-labelledby="exploreDropdown_active_<?php echo e($ac_user->id); ?>">
                                                            <li><a class="dropdown-item" href="<?php echo e(route('admin.vehicle.detail', optional($ac_user->active_vehicle->stock)->vehicle_track_id)); ?>">Dashboard</a></li>
                                                            <li><a class="dropdown-item" href="#">History</a></li>
                                                        </ul>
                                                    </div>
                                                 </td>
                                                <td class="align-middle text-end px-4">
                                                    <div class="d-flex">
                                                        <button class="btn btn-warning text-white mb-0 mx-1 action_btn_padding">
                                                            Suspend
                                                        </button>
                                                        <button class="btn btn-success text-white mb-0 mx-1 action_btn_padding">
                                                            Deallocate
                                                        </button>
                                                        <button class="btn btn-outline-success waves-effect mb-0 mx-1 action_btn_padding">
                                                            Exchange
                                                        </button>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                    </tbody>
                                </table>
                                <div class="d-flex justify-content-end mt-3 paginator">
                                    <?php echo e($active_users->links()); ?> <!-- Pagination links -->
                                </div>
                            </div>
                        </div>
                      </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <div class="loader-container" wire:loading>
        <div class="loader"></div>
    </div>
    <!-- Side Modal (Drawer) -->
    <!--[if BLOCK]><![endif]--><?php if($isModalOpen): ?>
    <div class="side-modal <?php echo e($isModalOpen ? 'open' : ''); ?>">
        <!--[if BLOCK]><![endif]--><?php if($selectedCustomer): ?>
            <div class="m-0 lh-1 border-bottom template-customizer-header position-relative py-4">
                <div class="d-flex justify-content-start align-items-center customer-name">
                    <div class="avatar-wrapper me-3">
                        <div class="avatar avatar-sm">
                        <!--[if BLOCK]><![endif]--><?php if($selectedCustomer->image): ?>
                        <img src="<?php echo e(asset($selectedCustomer->image)); ?>" alt="Avatar" class="rounded-circle">
                        <?php else: ?>
                        <div class="avatar-initial rounded-circle <?php echo e($colorClass); ?>">
                            <?php echo e(strtoupper(substr($selectedCustomer->name, 0, 1))); ?><?php echo e(strtoupper(substr(strrchr($selectedCustomer->name, ' '), 1, 1))); ?>

                        </div>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                    </div>
                    <div class="d-flex flex-column">
                        <a href="javascript:vid(0)" class="text-heading"><span
                            class="fw-medium text-truncate"><?php echo e(ucwords($selectedCustomer->name)); ?></span>
                        </a>
                        <small class="text-truncate"><?php echo e($selectedCustomer->email); ?> | <?php echo e($selectedCustomer->country_code); ?>

                        <?php echo e($selectedCustomer->mobile); ?></small>
                        <div>
                        </div>
                        <div class="d-flex align-items-center gap-2 position-absolute end-0 top-0 mt-6 me-5">
                        <a href="javascript:void(0)" wire:click="closeModal"
                            class="template-customizer-close-btn fw-light text-body" tabindex="-1">
                            <i class="ri-close-line ri-24px"></i>
                        </a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="side-modal-content">
                <?php if(session()->has('modal_message')): ?>
                    <div class="alert alert-success" id="modalflashMessage">
                        <?php echo e(session('modal_message')); ?>

                    </div>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                <div class="nav-align-top">
                    <ul class="nav nav-tabs nav-fill" role="tablist">
                      <li class="nav-item" role="presentation"> 
                        <button type="button" class="nav-link waves-effect modal-nav active" role="tab" data-bs-toggle="tab"
                          data-bs-target="#navs-justified-overview" aria-controls="navs-justified-overview" aria-selected="false"
                          tabindex="-1">
                          <span class="d-none d-sm-block">Overview 
                            </span>
                      </li>
                      <li class="nav-item" role="presentation">
                        <button type="button" class="nav-link waves-effect" role="tab" data-bs-toggle="tab"
                          data-bs-target="#navs-justified-history" aria-controls="navs-justified-history" aria-selected="false"
                          tabindex="-1">
                          <span class="d-none d-sm-block">
                            History 
                            </span>
                        </button>
                      </li>
                    </ul>
                </div>
                <div class="tab-content p-0 mt-6">
                    <div class="tab-pane fade active show" id="navs-justified-overview" role="tabpanel">
                        <div style="border-bottom: 1px solid #8d58ff;" class="mb-3">
                            <div class="d-flex align-items-center mb-3">
                                <!-- Icon -->
                                <div class="avatar me-3" style=" width:1.5rem; height: 1.5rem;">
                                  <div class="avatar-initial rounded 
                                        bg-label-dark document_type">
                                    <i class="ri-roadster-line ri-15px"></i>
                                  </div>
                                </div>
                                <!-- Document Name -->
                                <div>
                                    <span class="fw-medium text-truncate text-dark">Driving Licence</span>
                                </div>
                            </div>
                            <!--[if BLOCK]><![endif]--><?php if($selectedCustomer->driving_licence_status>0): ?>
                                <div class="d-flex">
                                <div class="col-6">
                                    <div class="card academy-content shadow-none border mx-2" style="width:150px">
                                        <div class="p-2">
                                        <div class="cursor-pointer">
                                        <img src="<?php echo e(asset($selectedCustomer->driving_licence)); ?>" alt="" style="max-width: 150px;max-height: 130px; width: 100%;">
                                        </div>
                                        <div class="text-center fw-medium text-truncate">Front</div>
                                        </div>
                                    </div>
                                </div>
                                    <div class="col-6">
                                        <div class="card academy-content shadow-none border mx-2" style="width:150px">
                                            <div class="p-2">
                                            <div class="cursor-pointer">
                                            <img src="<?php echo e(asset($selectedCustomer->driving_licence_back)); ?>" alt="" style="max-width: 150px;max-height: 130px; width: 100%;">
                                            </div>
                                            <div class="text-center fw-medium text-truncate">Back</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="d-flex my-4">
                                    <div class="col-4 text-center cursor-pointer">
                                        <span class="badge rounded-pill bg-label-secondary" wire:click="OpenPreviewImage('<?php echo e(asset($selectedCustomer->driving_licence)); ?>','<?php echo e(asset($selectedCustomer->driving_licence_back)); ?>','Driving Licence')">Preview</span>
                                    </div>
                                    <div class="col-4 text-center cursor-pointer">
                                        <!--[if BLOCK]><![endif]--><?php if($selectedCustomer->driving_licence_status==2): ?>
                                            <span class="badge rounded-pill bg-label-success">
                                                <i class="ri-check-line"></i> Approved
                                            </span>
                                        <?php else: ?>
                                            <span class="badge rounded-pill bg-label-secondary" wire:click="updateLog('2','driving_licence_status','Driving Licence',<?php echo e($selectedCustomer->id); ?>)">
                                                 Approve
                                            </span>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                    <div class="col-4 text-center cursor-pointer">
                                        <!--[if BLOCK]><![endif]--><?php if($selectedCustomer->driving_licence_status==3): ?>
                                            <span class="badge rounded-pill bg-label-danger"><i class="ri-close-line"></i> Rejected</span>
                                        <?php else: ?>
                                            <span class="badge rounded-pill bg-label-secondary" wire:click="OpenRejectForm('driving_licence_status','Driving Licence',<?php echo e($selectedCustomer->id); ?>)">Reject</span>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                </div>
                            <?php else: ?>
                                <div class="alert alert-danger">
                                    Driving licence not uploaded
                                </div>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <div style="border-bottom: 1px solid #8d58ff;" class="mb-3">
                            <!--[if BLOCK]><![endif]--><?php if($selectedCustomer->govt_id_card_status>0): ?>
                                <div class="d-flex align-items-center mb-3">
                                    <!-- Icon -->
                                    <div class="avatar me-3" style=" width:1.5rem; height: 1.5rem;">
                                    <div class="avatar-initial rounded 
                                            bg-label-dark document_type">
                                        <i class="ri-passport-line ri-15px"></i>
                                    </div>
                                    </div>
                                    <!-- Document Name -->
                                    <div>
                                        <span class="fw-medium text-truncate text-dark">Govt. ID Card</span>
                                    </div>
                                </div>
                                <div class="d-flex">
                                    <div class="col-6">
                                        <div class="card academy-content shadow-none border mx-2" style="width:150px">
                                            <div class="p-2">
                                            <div class="cursor-pointer">
                                            <img src="<?php echo e(asset($selectedCustomer->govt_id_card)); ?>" alt="" style="max-width: 150px;max-height: 130px; width: 100%;">
                                            </div>
                                            <div class="text-center fw-medium text-truncate">Front</div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-6">
                                        <div class="card academy-content shadow-none border mx-2" style="width:150px">
                                            <div class="p-2">
                                                <div class="cursor-pointer">
                                                <img src="<?php echo e(asset($selectedCustomer->govt_id_card_back)); ?>" alt="" style="max-width: 150px;max-height: 130px; width: 100%;">
                                                </div>
                                                <div class="text-center fw-medium text-truncate">Back</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="d-flex my-4">
                                    <div class="col-4 text-center cursor-pointer">
                                        <span class="badge rounded-pill bg-label-secondary" wire:click="OpenPreviewImage('<?php echo e(asset($selectedCustomer->govt_id_card)); ?>','<?php echo e(asset($selectedCustomer->govt_id_card_back)); ?>','Govt ID Card')"> Preview</span>
                                    </div>
                                    <div class="col-4 text-center cursor-pointer">
                                        <!--[if BLOCK]><![endif]--><?php if($selectedCustomer->govt_id_card_status==2): ?>
                                            <span class="badge rounded-pill bg-label-success">
                                                <i class="ri-check-line"></i> Approved
                                            </span>
                                        <?php else: ?>
                                            <span class="badge rounded-pill bg-label-secondary" wire:click="updateLog('2','govt_id_card_status','Govt ID Card',<?php echo e($selectedCustomer->id); ?>)">
                                                 Approve
                                            </span>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                    <div class="col-4 text-center cursor-pointer">
                                        <!--[if BLOCK]><![endif]--><?php if($selectedCustomer->govt_id_card_status==3): ?>
                                            <span class="badge rounded-pill bg-label-danger"><i class="ri-close-line"></i> Rejected</span>
                                        <?php else: ?>
                                            <span class="badge rounded-pill bg-label-secondary" wire:click="OpenRejectForm('govt_id_card_status','Govt ID Card',<?php echo e($selectedCustomer->id); ?>)">Reject</span>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                </div>
                            <?php else: ?>
                                <div class="alert alert-danger">
                                    Govt. ID not uploaded
                                </div>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <div style="border-bottom: 1px solid #8d58ff;" class="mb-3">
                            <!--[if BLOCK]><![endif]--><?php if($selectedCustomer->cancelled_cheque_status>0): ?>
                                <div class="d-flex align-items-center mb-3">
                                <!-- Icon -->
                                <div class="avatar me-3" style=" width:1.5rem; height: 1.5rem;">
                                    <div class="avatar-initial rounded 
                                            bg-label-dark document_type">
                                    <i class="ri-bank-line ri-15px"></i>
                                    </div>
                                </div>
                                <!-- Document Name -->
                                <div>
                                    <span class="fw-medium text-truncate text-dark">Cancelled Cheque</span>
                                </div>
                                </div>
                                <div class="d-flex">
                                    <div class="col-12">
                                        <div class="card academy-content shadow-none border mx-2" style="width:150px">
                                        <div class="p-2">
                                            <div class="cursor-pointer">
                                            <img src="<?php echo e(asset($selectedCustomer->cancelled_cheque)); ?>" alt=""
                                                style="max-width: 150px;max-height: 130px; width: 100%;">
                                            </div>
                                            <div class="text-center fw-medium text-truncate">Front</div>
                                        </div>
                                        </div>
                                    </div>
                                    
                                </div>
                                <div class="d-flex my-4">
                                <div class="col-4 text-center cursor-pointer">
                                    <span class="badge rounded-pill bg-label-secondary"> Preview</span>
                                </div>
                                <div class="col-4 text-center cursor-pointer">
                                    <!--[if BLOCK]><![endif]--><?php if($selectedCustomer->cancelled_cheque_status==2): ?>
                                    <span class="badge rounded-pill bg-label-success">
                                    <i class="ri-check-line"></i> Approved
                                    </span>
                                    <?php else: ?>
                                    <span class="badge rounded-pill bg-label-secondary"
                                    wire:click="updateLog('2','cancelled_cheque_status','Cancelled Cheque',<?php echo e($selectedCustomer->id); ?>)">
                                    Approve
                                    </span>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </div>
                                <div class="col-4 text-center cursor-pointer">
                                    <!--[if BLOCK]><![endif]--><?php if($selectedCustomer->cancelled_cheque_status==3): ?>
                                    <span class="badge rounded-pill bg-label-danger"><i class="ri-close-line"></i>
                                    Rejected</span>
                                    <?php else: ?>
                                    <span class="badge rounded-pill bg-label-secondary"
                                    wire:click="OpenRejectForm('cancelled_cheque_status','Cancelled Cheque',<?php echo e($selectedCustomer->id); ?>)">Reject</span>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </div>
                                </div>
                            <?php else: ?>
                                <div class="alert alert-danger">
                                    Cancelled Cheque not uploaded
                                </div>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <div style="border-bottom: 1px solid #8d58ff;" class="mb-3">
                            <!--[if BLOCK]><![endif]--><?php if($selectedCustomer->current_address_proof_status>0): ?>
                                <div class="d-flex align-items-center mb-3">
                                <!-- Icon -->
                                <div class="avatar me-3" style=" width:1.5rem; height: 1.5rem;">
                                    <div class="avatar-initial rounded 
                                            bg-label-dark document_type">
                                    <i class="ri-home-line ri-15px"></i>
                                    </div>
                                </div>
                                <!-- Document Name -->
                                <div>
                                    <span class="fw-medium text-truncate text-dark">Current Address Proof</span>
                                </div>
                                </div>
                                <div class="d-flex">
                                <div class="col-6">
                                    <div class="card academy-content shadow-none border mx-2" style="width:150px">
                                    <div class="p-2">
                                        <div class="cursor-pointer">
                                        <img src="<?php echo e(asset($selectedCustomer->current_address_proof)); ?>" alt=""
                                            style="max-width: 150px;max-height: 130px; width: 100%;">
                                        </div>
                                        <div class="text-center fw-medium text-truncate">Front</div>
                                    </div>
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div class="card academy-content shadow-none border mx-2" style="width:150px">
                                    <div class="p-2">
                                        <div class="cursor-pointer">
                                        <img src="<?php echo e(asset($selectedCustomer->current_address_proof_back)); ?>" alt=""
                                            style="max-width: 150px;max-height: 130px; width: 100%;">
                                        </div>
                                        <div class="text-center fw-medium text-truncate">Back</div>
                                    </div>
                                    </div>
                                </div>
                                </div>
                                <div class="d-flex my-4">
                                <div class="col-4 text-center cursor-pointer">
                                    <span class="badge rounded-pill bg-label-secondary"> Preview</span>
                                </div>
                                <div class="col-4 text-center cursor-pointer">
                                    <!--[if BLOCK]><![endif]--><?php if($selectedCustomer->current_address_proof_back==2): ?>
                                    <span class="badge rounded-pill bg-label-success">
                                    <i class="ri-check-line"></i> Approved
                                    </span>
                                    <?php else: ?>
                                    <span class="badge rounded-pill bg-label-secondary"
                                    wire:click="updateLog('2','current_address_proof_back','Current Address Proof',<?php echo e($selectedCustomer->id); ?>)">
                                    Approve
                                    </span>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </div>
                                <div class="col-4 text-center cursor-pointer">
                                    <!--[if BLOCK]><![endif]--><?php if($selectedCustomer->current_address_proof_back==3): ?>
                                    <span class="badge rounded-pill bg-label-danger"><i class="ri-close-line"></i>
                                    Rejected</span>
                                    <?php else: ?>
                                    <span class="badge rounded-pill bg-label-secondary"
                                    wire:click="OpenRejectForm('current_address_proof_back','Current Address Proof',<?php echo e($selectedCustomer->id); ?>)">Reject</span>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </div>
                                </div>
                            <?php else: ?>
                                <div class="alert alert-danger">
                                    Current address proof not uploaded
                                </div>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <div class="text-center">
                            <!--[if BLOCK]><![endif]--><?php if($selectedCustomer->is_verified=="verified"): ?>
                            <button type="button" wire:click="VerifyKyc('unverified',<?php echo e($selectedCustomer->id); ?>)" class="btn btn-primary text-white mb-0 custom-input-sm ms-2">
                                KYC VERIFIED
                            </button>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            <!--[if BLOCK]><![endif]--><?php if($selectedCustomer->is_verified=="unverified"): ?>
                                <button type="button" wire:click="VerifyKyc('vefiry',<?php echo e($selectedCustomer->id); ?>)" class="btn btn-danger text-white mb-0 custom-input-sm ms-2">
                                    VERIFY KYC
                                </button>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                    </div>
                    <div class="tab-pane fade" id="navs-justified-history" role="tabpanel">
                        <ul class="timeline pb-0 mb-0">
                            <!--[if BLOCK]><![endif]--><?php if(count($selectedCustomer->doc_logs)>0): ?>
                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $selectedCustomer->doc_logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $logs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="timeline-item timeline-item-transparent border-primary">
                                    <span class="timeline-point timeline-point-primary"></span>
                                    <div class="timeline-event">
                                        <div class="timeline-header mb-1">
                                        <h6 class="mb-0"><?php echo e(ucwords($logs->document_type)); ?> | <?php echo e(ucwords($logs->status)); ?></h6>
                                        <small class="text-muted"><?php echo e(date('d M y h:i A', strtotime($logs->created_at))); ?></small>
                                        </div>
                                        <!--[if BLOCK]><![endif]--><?php if($logs->remarks): ?>
                                            <code>Remarks</code>
                                            <p class="mt-1 mb-3"><small><?php echo e($logs->remarks); ?></small></p>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </div>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                            <?php else: ?>
                                <div class="alert alert-danger">
                                   Sorry! data not found!
                                </div>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                          </ul>
                    </div>
                </div>
            </div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    <!-- Overlay -->
    <!--[if BLOCK]><![endif]--><?php if($isModalOpen): ?>
        <div class="overlay" wire:click="closeModal"></div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    <!--[if BLOCK]><![endif]--><?php if($isRejectModal): ?>
        <div class="modal fade show d-block" tabindex="-1" role="dialog" style="background: rgba(0, 0, 0, 0.5);z-index: 99999;">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title"><?php echo e($document_type); ?></h5>
                        <button type="button" class="btn-close" wire:click="closeRejectModal"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">Remark</label>
                            <textarea class="form-control" wire:model="remarks"></textarea>
                            <?php if(session()->has('remarks')): ?>
                            <div class="alert alert-danger">
                                <?php echo e(session('remarks')); ?>

                            </div>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-danger" wire:click="updateLog('3','<?php echo e($field); ?>','<?php echo e($document_type); ?>',<?php echo e($id); ?>)">Reject</button>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    <!--[if BLOCK]><![endif]--><?php if($isAssignedModal): ?>
        <div class="modal fade show d-block" tabindex="-1" role="dialog" style="background: rgba(0, 0, 0, 0.5);z-index: 99999;">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Assign Vehicle</h5>
                        <button type="button" class="btn-close" wire:click="closeAssignedModal"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label">Vehicle Model</label>
                            <div>
                                <select class="form-control border border-2 p-2" wire:model="vehicle_model">
                                    <option value="" selected hidden>Select vehicle</option>
                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle_index=>$vehicle_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($vehicle_item->id); ?>"><?php echo e($vehicle_item->vehicle_number); ?> | <?php echo e(optional($vehicle_item->product)->title ?? 'N/A'); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                </select>
                            </div>
                            <div class="mt-2">
                                <?php if(session()->has('assign_error')): ?>
                                <div class="alert alert-danger">
                                    <?php echo e(session('assign_error')); ?>

                                </div>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-success" wire:click="updateAssignRider()">Assign</button>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    <!--[if BLOCK]><![endif]--><?php if($isPreviewimageModal): ?>
        <div class="modal fade show d-block" tabindex="-1" role="dialog" style="background: rgba(0, 0, 0, 0.5);z-index: 99999;">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title"><?php echo e($document_type); ?></h5>
                        <button type="button" class="btn-close" wire:click="closePreviewImage"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <div class="card academy-content shadow-none border mx-2">
                                <div class="p-2">
                                    <div class="cursor-pointer">
                                        <img src="<?php echo e($preview_front_image); ?>" alt="" width="100%">
                                    </div>
                                </div>
                            </div>
                            <div class="card academy-content shadow-none border mx-2 my-2">
                                <div class="p-2">
                                    <div class="cursor-pointer">
                                        <img src="<?php echo e($preview_back_image); ?>" alt="" width="100%">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

</div>
<?php $__env->startSection('page-script'); ?>
<script>
    setTimeout(() => {
        const flashMessage = document.getElementById('modalflashMessage');
        if (flashMessage) flashMessage.remove();
    }, 3000); // Auto-hide flash message after 3 seconds
    setTimeout(() => {
        const flashMessage = document.getElementById('flashMessage');
        if (flashMessage) flashMessage.remove();
    }, 3000); // Auto-hide flash message after 3 seconds
</script>
<?php $__env->stopSection(); ?>
<?php /**PATH C:\xampp\htdocs\new_ewent\resources\views/livewire/admin/rider-engagement.blade.php ENDPATH**/ ?>
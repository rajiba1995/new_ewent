
<div class="row mb-4">
    <div class="col-lg-12 d-flex justify-content-between">
        <div>
            <h5 class="mb-0">Model Management</h5>
            <div>
                 <small class="text-dark fw-medium">Dashboard</small>
                 <small class="text-light fw-medium arrow">Models</small>
            </div>
         </div>
        <div>
            <a href="<?php echo e(route('admin.product.add')); ?>"  class="btn btn-primary">
                <i class="ri-add-line ri-16px me-0 me-sm-2 align-baseline"></i>
                Add Model
            </a>
        </div>
    </div>
    <div class="col-lg-12 col-md-6 mb-md-0 mb-4">
        <div class="row">
            <div class="col-12">
                <div class="card my-4">
                    <div class="card-header pb-0">
                        <div class="row">
                            <!--[if BLOCK]><![endif]--><?php if(session()->has('message')): ?>
                                <div class="alert alert-success" id="flashMessage">
                                    <?php echo e(session('message')); ?>

                                </div>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            
                            <?php if(session()->has('error')): ?>
                                <div class="alert alert-danger">
                                    <?php echo e(session('error')); ?>

                                </div>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                        <div class="row">
                            <div class="col-lg-12 d-flex justify-content-end my-auto">
                                <div class="d-flex align-items-center">
                                    <input type="text" wire:model.debounce.300ms="search" 
                                           class="form-control border border-2 p-2 custom-input-sm" 
                                           placeholder="Search here...">
                                    <button type="button" wire:click="searchButtonClicked" 
                                            class="btn btn-dark text-white mb-0 custom-input-sm ms-2">
                                        <span class="material-icons">search</span>
                                    </button>
                                    <!-- Refresh Button -->
                                    <button type="button" wire:click="resetSearch" class="btn btn-danger text-white mb-0 custom-input-sm ms-2">
                                            <i class="ri-restart-line"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-body px-0 pb-2 mt-2">
                        <div class="table-responsive p-0">
                        <table class="table align-items-center mb-0 product-list">
                            <thead>
                                <tr>
                                    <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 align-middle">
                                        SL
                                    </th>
                                    <th class="text-center text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 align-middle" width="25%">
                                        Title
                                    </th>
                                    <th class="text-end text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 align-middle px-4">
                                        Selling Price
                                    </th>
                                    <th class="text-end text-uppercase text-secondary text-xxs font-weight-bolder opacity-7 align-middle px-4">
                                        Actions
                                    </th>
                                </tr>
                            </thead>
                            <tbody>
                                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="align-middle text-center"><?php echo e($k + 1); ?></td>
                                        <td class="sorting_1" width="25%">
                                            <div class="d-flex justify-content-start align-items-center product-name">
                                                <div class="avatar-wrapper me-4">
                                                    <div class="avatar rounded-2 bg-label-secondary"><img
                                                            src="<?php echo e(asset($product->image)); ?>"
                                                            alt="Product-9" class="rounded-2"></div>
                                                </div>
                                                <div class="d-flex flex-column">
                                                    <span class="badge bg-label-primary"><?php echo e($product->product_sku); ?></span>
                                                    <span class="text-heading fw-medium"> <?php echo e(ucwords($product->title)); ?></span>
                                                    <small class="text-truncate d-none d-sm-block"> <?php echo e($product->types); ?></small></div>
                                            </div>
                                        </td>
                                        <td class="align-middle price-details">
                                            <ul>
                                                <!--[if BLOCK]><![endif]--><?php if($product->is_selling == 1): ?>
                                                    <span class="badge bg-label-success price-title">SELLING PRICE</span>
                                                    <li class="price-item">
                                                        <span class="label">Actual Price:</span>
                                                        <span class="actual-value"><?php echo e(env('APP_CURRENCY')); ?><?php echo e($product->base_price); ?></span>
                                                    </li>
                                                    <li class="price-item">
                                                        <span class="label">Offer Price:</span>
                                                        <span class="value"><?php echo e(env('APP_CURRENCY')); ?><?php echo e($product->display_price); ?></span>
                                                    </li>
                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                
                                            </ul>
                                        </td>
                                                                            
                                        
                                        <td class="align-middle text-end px-4">
                                            
                                            <button data-bs-toggle="modal" data-bs-target="#productDetailsModal<?php echo e($product->id); ?>" class="btn btn-sm btn-icon view-record btn-text-secondary rounded-pill waves-effect btn-sm" title="View">
                                                <i class="ri-eye-line ri-20px text-primary"></i> 
                                            </button>
                                            
                                            <a href="<?php echo e(route('admin.product.update',$product->id)); ?>" class="btn btn-sm btn-icon edit-record btn-text-secondary rounded-pill waves-effect btn-sm" title="Edit">
                                                <i class="ri-edit-box-line ri-20px text-info"></i>
                                            </a>
                                            <button wire:click="destroy(<?php echo e($product->id); ?>)" class="btn btn-sm btn-icon delete-record btn-text-secondary rounded-pill waves-effect btn-sm" title="Delete">
                                                <i class="ri-delete-bin-7-line ri-20px text-danger"></i>
                                            </button>
                                            <a href="<?php echo e(route('admin.product.stocks.vehicle',$product->id)); ?>">
                                            <span class="control"></span></a>
                                            <div class="modal fade" id="productDetailsModal<?php echo e($product->id); ?>" tabindex="-1" aria-labelledby="productDetailsLabel<?php echo e($product->id); ?>" aria-hidden="true">
                                                <div class="modal-dialog" role="document">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="productDetailsLabel<?php echo e($product->id); ?>">Details of <?php echo e($product->title); ?></h5>
                                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <div class="table-responsive text-nowrap">
                                                                <table class="table table-striped text-start">
                                                                    <thead>
                                                                        <!--[if BLOCK]><![endif]--><?php if($product->category): ?>
                                                                            <tr>
                                                                                <th>Category</th>
                                                                                <th><?php echo e($product->category->title); ?></th>
                                                                            </tr>
                                                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                                    </thead>
                                                                    <tbody class="table-border-bottom-0">
                                                                        
                                                                        <tr>
                                                                            <td>Features</td>
                                                                            <td>
                                                                                <!--[if BLOCK]><![endif]--><?php if(count($product->features)>0): ?>
                                                                                <ul>
                                                                                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $product->features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                        <li><?php echo e($items->title); ?></li>
                                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                                                                </ul>
                                                                                <?php else: ?>
                                                                                    <div class="alert alert-danger">
                                                                                        features not available
                                                                                    </div>
                                                                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                                                            </td>
                                                                        </tr>
                                                                    </tbody>
                                                                </table>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                            </tbody>
                        </table>

                            <div class="d-flex justify-content-end mt-2">
                                <?php echo e($products->links('pagination::bootstrap-4')); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="loader-container" wire:loading>
        <div class="loader"></div>
      </div>
</div>
<?php /**PATH C:\xampp\htdocs\new_ewent\resources\views/livewire/product/master-product.blade.php ENDPATH**/ ?>
<div>
    <div class="row mb-2">
        <div class="row gx-4">
            <div class="col-auto my-auto">
              <div class="h-100">
                <h5 class="mb-1"> <?php echo e($product_name); ?></h5>
              </div>
            </div>
            <div class="col-lg-4 col-md-6 my-sm-auto ms-sm-auto me-sm-0 mx-auto mt-3">
              <div class="nav-wrapper position-relative end text-end">
                <!-- Back Button -->
                <a class="btn btn-dark btn-sm" href="javascript:history.back();" role="button">
                  <i class="ri-arrow-go-back-line ri-16px me-0 me-sm-2 align-baseline"></i>
                  Back
                </a>
              </div>
            </div>
        </div>
      <div class="col-lg-12 col-md-12 mb-md-0 mb-4">
        <div class="row">
          <div class="col-12">
            <div class="card my-4">
              <div class="card-header pb-2">
                <div class="row">
                  <!--[if BLOCK]><![endif]--><?php if(session()->has('message')): ?>
                  <div class="alert alert-success" id="flashMessage">
                    <?php echo e(session('message')); ?>

                  </div>
                  <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                </div>
                <div class="row">
                  <div class="col-lg-6 col-7">
                    <h6>Vehicle List</h6>
                  </div>
                  <div class="col-lg-6 col-5 my-auto text-end">
                    <div class="ms-md-auto d-flex align-items-center">
                      <input type="text" wire:model.debounce.500ms="search"
                        class="form-control border border-2 p-2 custom-input-sm" placeholder="Enter Vehicle Number">
                      <button type="button" wire:click="searchButtonClicked" class="btn btn-dark text-white mb-0 custom-input-sm">
                        <span class="material-icons">search</span>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
              <div class="card-body px-0 pb-2 mt-2 vehicle_body">
                <div class="row mx-2 mt-2">
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-12 col-sm-6 col-md-3 col-lg-2 mb-3 px-1">
                        <div class="vehicle-card">
                            <img src="<?php echo e(asset($item->product->image)); ?>" alt="Vehicle Image" class="vehicle-image">
                            <h3 class="vehicle-number"><?php echo e($item->vehicle_number); ?></h3>
                                <!--[if BLOCK]><![endif]--><?php if($vehicleData = VehicleStatus($item->id)): ?> 
                                    <!-- This vehicle is assigned to an order -->
                                    <div class="text-center">
                                        <a href="<?php echo e(route('admin.order.detail',$vehicleData['order_id'])); ?>"><span class="badge bg-label-<?php echo e($vehicleData['class']); ?> mb-0 cursor-pointer" title=""><?php echo e($vehicleData['message']); ?></span></a>
                                    </div>
                                <?php else: ?>
                                <div class="icon-container justify-content-<?php echo e(vehicleLog($item->id)==0?"between":"center"); ?>">
                                    <div>
                                        <span class="badge bg-label-<?php echo e($item->status == 1 ? 'success' : 'danger'); ?> mb-0 cursor-pointer" 
                                            wire:click="UpdateStatus('<?php echo e($item->id); ?>')" 
                                            title="Update Vehicle Status">
                                            <?php echo e($item->status == 1 ? 'Active' : 'Inactive'); ?>

                                        </span>
                                    </div>
                                    <!--[if BLOCK]><![endif]--><?php if(vehicleLog($item->id)==0): ?>
                                        <div>
                                            
                                    
                                            <span class="icon tf-icons ri-delete-bin-line text-danger cursor-pointer" 
                                                wire:click="deleteVehicle('<?php echo e($item->id); ?>')" 
                                                title="Delete Vehicle"></span>
                                        </div>
                                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                </div>
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    <div class="d-flex justify-content-end mt-2">
                        <?php echo e($data->links('pagination::bootstrap-4')); ?>

                    </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    
      
    </div>
    
    <div class="loader-container" wire:loading>
      <div class="loader"></div>
    </div>
    </div>
    <?php $__env->startSection('page-script'); ?>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
         window.addEventListener('showConfirm', function (event) {
        let itemId = event.detail[0].itemId;
        Swal.fire({
            title: "Are you sure?",
            text: "You won't be able to revert this!",
            icon: "warning",
            showCancelButton: true,
            confirmButtonColor: "#3085d6",
            cancelButtonColor: "#d33",
            confirmButtonText: "Yes, delete it!"
        }).then((result) => {
            if (result.isConfirmed) {
                window.Livewire.find('<?php echo e($_instance->getId()); ?>').call('deleteItem', itemId); // Calls Livewire method directly
                Swal.fire("Deleted!", "Your item has been deleted.", "success");
            }
        });
    });
    </script>
    <?php $__env->stopSection(); ?>
    <?php /**PATH C:\xampp\htdocs\new_ewent\resources\views/livewire/product/product-wise-vehicle.blade.php ENDPATH**/ ?>
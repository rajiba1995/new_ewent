<!-- BEGIN: Theme CSS-->
<!-- Fonts -->
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&ampdisplay=swap" rel="stylesheet">

<?php echo app('Illuminate\Foundation\Vite')(['resources/assets/vendor/fonts/remixicon/remixicon.scss']); ?>
<!-- Core CSS -->
<?php echo app('Illuminate\Foundation\Vite')([
  'resources/assets/vendor/scss/core.scss',
  'resources/assets/vendor/scss/theme-default.scss',
  'resources/assets/css/demo.css'
]); ?>

<link rel="stylesheet" href="<?php echo e(asset('build/assets/datatable.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('build/assets/style.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('build/assets/core-BdqwDRjO.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('build/assets/page-auth.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('build/assets/theme-semi-dark-V_cttLte.css')); ?>">
<link rel="stylesheet" href="https://cdn.ckeditor.com/ckeditor5/44.1.0/ckeditor5.css">

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css" rel="stylesheet" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js"></script>



<?php echo app('Illuminate\Foundation\Vite')(['resources/assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.scss']); ?>
<?php echo $__env->yieldContent('vendor-style'); ?>

<!-- Page Styles -->
<?php echo $__env->yieldContent('page-style'); ?>
<?php /**PATH C:\xampp\htdocs\new_ewent\resources\views/components/layouts/sections/styles.blade.php ENDPATH**/ ?>